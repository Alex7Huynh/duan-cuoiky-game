using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace SelectionBoxOneStepFurther
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        Texture2D mDottedLine;

        Rectangle mSelectionBox;

        MouseState mPreviousMouseState;

        Texture2D mCircle;

        Vector2 mBlueUnitPosition;
        Vector2 mBlueTargetPosition = new Vector2(-1, -1);
        Vector2 mBlueDirection;
        bool mBlueUnitSelected = false;

        Vector2 mRedUnitPosition;
        Vector2 mRedTargetPosition = new Vector2(-1, -1);
        Vector2 mRedDirection;
        bool mRedUnitSelected = false;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            //Make the mouse pointer visible in the game window
            this.IsMouseVisible = true;

            //Iniitliaze the Selection box's rectangle. Currently no selection box is drawn
            //so set it's x and y position to 0 and it's height and width to 0
            mSelectionBox = new Rectangle(0, 0, 0, 0);

            //Initialize the previous mouse state. This stores the current state of the mouse
            mPreviousMouseState = Mouse.GetState();

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            mDottedLine = Content.Load<Texture2D>("DottedLine");
            mCircle = Content.Load<Texture2D>("Circle");

            mRedUnitPosition = new Vector2(50, 50);
            mBlueUnitPosition = new Vector2(100, 50);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here

            //Exit the game if the Escape key is pressed
            if (Keyboard.GetState().IsKeyDown(Keys.Escape) == true)
            {
                this.Exit();
            }

            //Get the current state of the Mouse
            MouseState aMouse = Mouse.GetState();

            //If the user has just clicked the Left mouse button, then set the start location for the Selection box
            if (aMouse.LeftButton == ButtonState.Pressed & mPreviousMouseState.LeftButton == ButtonState.Released)
            {
                //Set the starting location for the selectiong box to the current location
                //where the Left button was initially clicked.
                mSelectionBox = new Rectangle(aMouse.X, aMouse.Y, 0, 0);
            }

            //If the user is still holding the Left button down, then continue to re-size the 
            //selection square based on where the mouse has currently been moved to.
            if (aMouse.LeftButton == ButtonState.Pressed)
            {
                //The starting location for the selection box remains the same, but increase (or decrease)
                //the size of the Width and Height but taking the current location of the mouse minus the
                //original starting location.
                mSelectionBox = new Rectangle(mSelectionBox.X, mSelectionBox.Y, aMouse.X - mSelectionBox.X, aMouse.Y - mSelectionBox.Y);
            }

            //If the user has released the left mouse button, then reset the selection square
            if (aMouse.LeftButton == ButtonState.Released && mPreviousMouseState.LeftButton == ButtonState.Pressed)
            {
                //check if the units are selected
                BoundingBox aSelection = new BoundingBox(new Vector3(mSelectionBox.X, mSelectionBox.Y, 0), new Vector3(mSelectionBox.X + mSelectionBox.Width, mSelectionBox.Y + mSelectionBox.Height, 0));
                BoundingBox aBlue = new BoundingBox(new Vector3(mBlueUnitPosition.X, mBlueUnitPosition.Y, 0), new Vector3(mBlueUnitPosition.X + 50, mBlueUnitPosition.Y + 50, 0));
                BoundingBox aRed = new BoundingBox(new Vector3(mRedUnitPosition.X, mRedUnitPosition.Y, 0), new Vector3(mRedUnitPosition.X + 50, mRedUnitPosition.Y + 50, 0));

                if (aSelection.Intersects(aBlue) == true)
                {
                    mBlueUnitSelected = true;
                }
                else
                {
                    mBlueUnitSelected = false;
                }

                if (aSelection.Intersects(aRed) == true)
                {
                    mRedUnitSelected = true;
                }
                else
                {
                    mRedUnitSelected = false;
                }


                //Reset the selection square to no position with no height and width
                mSelectionBox = new Rectangle(0, 0, 0, 0);
            }


            if (aMouse.RightButton == ButtonState.Pressed && mPreviousMouseState.RightButton == ButtonState.Released)
            {
                //Move selected units to that location
                if (mBlueUnitSelected == true)
                {
                    mBlueTargetPosition = new Vector2(aMouse.X, aMouse.Y);

                    mBlueDirection = mBlueUnitPosition - mBlueTargetPosition;
                    mBlueDirection.Normalize();
                    mBlueDirection = mBlueDirection * -1;
                }

                if (mRedUnitSelected == true)
                {
                    mRedTargetPosition = new Vector2(aMouse.X, aMouse.Y);

                    mRedDirection = mRedUnitPosition - mRedTargetPosition;
                    mRedDirection.Normalize();
                    mRedDirection = mRedDirection * -1;
                }

            }

            //Store the previous mouse state
            mPreviousMouseState = aMouse;


            if (mBlueTargetPosition.X != -1)
            {
                //Move the blue circle from it's current position to the target
                Vector2 aDirecton = mBlueUnitPosition - mBlueTargetPosition;
                aDirecton.Normalize();
                aDirecton = aDirecton * -1;

                if (Math.Sign(aDirecton.X) == Math.Sign(mBlueDirection.X) && Math.Sign(aDirecton.Y) == Math.Sign(mBlueDirection.Y))
                {
                    Vector2 aNewPosition = mBlueUnitPosition + (aDirecton * 2);
                    BoundingBox aBlue = new BoundingBox(new Vector3(aNewPosition.X, aNewPosition.Y, 0), new Vector3(aNewPosition.X + 50, aNewPosition.Y + 50, 0));
                    BoundingBox aRed = new BoundingBox(new Vector3(mRedUnitPosition.X, mRedUnitPosition.Y, 0), new Vector3(mRedUnitPosition.X + 50, mRedUnitPosition.Y + 50, 0));

                    if (aBlue.Intersects(aRed) == true)
                    {
                        mBlueTargetPosition.X = -1;
                    }
                    else
                    {
                        mBlueUnitPosition = mBlueUnitPosition + (aDirecton * 2);
                    }
                }
                else
                {
                    mBlueTargetPosition.X = -1;
                }
            }

            if (mRedTargetPosition.X != -1)
            {
                //Move the red unit from it's current position to the target
                Vector2 aDirecton = mRedUnitPosition - mRedTargetPosition;
                aDirecton.Normalize();
                aDirecton = aDirecton * -1;

                if (Math.Sign(aDirecton.X) == Math.Sign(mRedDirection.X) && Math.Sign(aDirecton.Y) == Math.Sign(mRedDirection.Y))
                {
                    Vector2 aNewPosition = mRedUnitPosition + (aDirecton * 2);
                    BoundingBox aBlue = new BoundingBox(new Vector3(mBlueUnitPosition.X, mBlueUnitPosition.Y, 0), new Vector3(mBlueUnitPosition.X + 50, mBlueUnitPosition.Y + 50, 0));
                    BoundingBox aRed = new BoundingBox(new Vector3(aNewPosition.X, aNewPosition.Y, 0), new Vector3(aNewPosition.X + 50, aNewPosition.Y + 50, 0));

                    if (aBlue.Intersects(aRed) == true)
                    {
                        mRedTargetPosition.X = -1;
                    }
                    else
                    {
                        mRedUnitPosition = mRedUnitPosition + (aDirecton * 2);
                    }
                }
                else
                {
                    mRedTargetPosition.X = -1;
                }
            }

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            graphics.GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here

            //Begin drawing with the batch
            spriteBatch.Begin();

            //Draw the horizontal portions of the selection box 
            DrawHorizontalLine(mSelectionBox.Y);
            DrawHorizontalLine(mSelectionBox.Y + mSelectionBox.Height);

            //Draw the verticla portions of the selection box 
            DrawVerticalLine(mSelectionBox.X);
            DrawVerticalLine(mSelectionBox.X + mSelectionBox.Width);

            if (mBlueUnitSelected == true)
            {
                spriteBatch.Draw(mCircle, new Rectangle((int)mBlueUnitPosition.X, (int)mBlueUnitPosition.Y, 50, 50), Color.Blue);
            }
            else
            {
                spriteBatch.Draw(mCircle, new Rectangle((int)mBlueUnitPosition.X, (int)mBlueUnitPosition.Y, 50, 50), Color.LightBlue);

            }


            if (mRedUnitSelected == true)
            {
                spriteBatch.Draw(mCircle, new Rectangle((int)mRedUnitPosition.X, (int)mRedUnitPosition.Y, 50, 50), Color.Red);
            }
            else
            {
                spriteBatch.Draw(mCircle, new Rectangle((int)mRedUnitPosition.X, (int)mRedUnitPosition.Y, 50, 50), Color.LightSalmon);

            }
            //End the drawing with the batch 
            spriteBatch.End();

            base.Draw(gameTime);
        }

        private void DrawHorizontalLine(int thePositionY)
        {
            //When the width is greater than 0, the user is selecting an area to the right of the starting point
            if (mSelectionBox.Width > 0)
            {
                //Draw the line starting at the startring location and moving to the right
                for (int aCounter = 0; aCounter <= mSelectionBox.Width - 10; aCounter += 10)
                {
                    if (mSelectionBox.Width - aCounter >= 0)
                    {
                        spriteBatch.Draw(mDottedLine, new Rectangle(mSelectionBox.X + aCounter, thePositionY, 10, 5), Color.White);
                    }
                }
            }
            //When the width is less than 0, the user is selecting an area to the left of the starting point
            else if (mSelectionBox.Width < 0)
            {
                //Draw the line starting at the starting location and moving to the left
                for (int aCounter = -10; aCounter >= mSelectionBox.Width; aCounter -= 10)
                {
                    if (mSelectionBox.Width - aCounter <= 0)
                    {
                        spriteBatch.Draw(mDottedLine, new Rectangle(mSelectionBox.X + aCounter, thePositionY, 10, 5), Color.White);
                    }
                }
            }
        }

        private void DrawVerticalLine(int thePositionX)
        {
            //When the height is greater than 0, the user is selecting an area below the starting point
            if (mSelectionBox.Height > 0)
            {
                //Draw the line starting at the starting loctino and moving down
                for (int aCounter = -2; aCounter <= mSelectionBox.Height; aCounter += 10)
                {
                    if (mSelectionBox.Height - aCounter >= 0)
                    {
                        spriteBatch.Draw(mDottedLine, new Rectangle(thePositionX, mSelectionBox.Y + aCounter, 10, 5), new Rectangle(0, 0, mDottedLine.Width, mDottedLine.Height), Color.White, MathHelper.ToRadians(90), new Vector2(0, 0), SpriteEffects.None, 0);
                    }
                }
            }
            //When the height is less than 0, the user is selecting an area above the starting point
            else if (mSelectionBox.Height < 0)
            {
                //Draw the line starting at the start location and moving up
                for (int aCounter = 0; aCounter >= mSelectionBox.Height; aCounter -= 10)
                {
                    if (mSelectionBox.Height - aCounter <= 0)
                    {
                        spriteBatch.Draw(mDottedLine, new Rectangle(thePositionX - 10, mSelectionBox.Y + aCounter, 10, 5), Color.White);
                    }
                }
            }
        }
    }
}
