using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace FadeInFadeOut
{
    class Fade
    {
        Texture2D mTexture;

        float mCurrentAlpha = 0.0f;
        double mUpdateAlphaInterval;

        float mAlphaIncrement = .01f;
        public float Increment
        {
            get
            {
                return mAlphaIncrement;
            }
        }

        public Fade(ContentManager theLoader, string theFilePathAndName, Random theRandom)
        {
            mTexture = theLoader.Load<Texture2D>(theFilePathAndName) as Texture2D;
            mUpdateAlphaInterval = ((double)theRandom.Next(1, 9) / 100) + ((double)theRandom.Next(1, 9) / 10) + ((double)theRandom.Next(0, 5));
            mAlphaIncrement = (float)theRandom.Next(1, 4) / 10;
        }

        bool mFaded = false;
        public bool Faded
        {
            get
            {
                return mFaded;
            }
            set
            {
                mFaded = value;
            }
        }

        public int Width
        {
            get
            {
                return mTexture.Width;
            }
        }

        public int Height
        {
            get
            {
                return mTexture.Height;
            }
        }


        public void Update(GameTime theGameTime)
        {
            mUpdateAlphaInterval -= theGameTime.ElapsedGameTime.TotalSeconds;
            if (mUpdateAlphaInterval <= 0)
            {
                mCurrentAlpha += mAlphaIncrement;
                if (mCurrentAlpha < 0 || mCurrentAlpha > 1)
                {
                    mFaded = true;
                    mCurrentAlpha = MathHelper.Clamp(mCurrentAlpha, 0, 1);
                }
            }           
        }

        public void ReverseFade(Random theRandom)
        {
            mUpdateAlphaInterval = ((double)theRandom.Next(1, 9) / 100) + ((double)theRandom.Next(1, 9) / 10) + ((double)theRandom.Next(0, 5));
            
            if (mAlphaIncrement > 0) 
            {
                mAlphaIncrement = (float)(theRandom.Next(1, 4) * -1)/10;            
            }
            else
            {
                mAlphaIncrement = (float)theRandom.Next(1, 4)/10;            
            }

            mFaded = false;          
        }

        public void Draw(SpriteBatch theBatch, int theXPosition, int theYPosition)
        {
            theBatch.Draw(mTexture, new Rectangle(theXPosition, theYPosition, mTexture.Width, mTexture.Height), Color.Lerp(Color.White, Color.Transparent, mCurrentAlpha));
        }
        
    }
}
